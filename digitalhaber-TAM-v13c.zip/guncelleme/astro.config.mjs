import { defineConfig } from 'astro/config';
import sitemap from '@astrojs/sitemap';

export default defineConfig({
  site: 'https://www.digitalhaber.com',
  integrations: [sitemap({ filter: (page) => !page.includes('/arama') && !page.includes('/en/search') && !page.includes('/kaydedilenler') && !page.includes('/en/saved') })],
});
